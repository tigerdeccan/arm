﻿#------------------------------------------------------------------------
# Source File Information (DO NOT MODIFY)
# Source ID: 2b75fcb1-e2f9-4fed-ab79-3e5804cdb8f7
# Source File: C:\Users\khanm1\Desktop\hrpro AD tools\new user.psf\new user.psf
#------------------------------------------------------------------------
#region File Recovery Data (DO NOT MODIFY)
<#RecoveryData:
B28AAB+LCAAAAAAABADlvVmv28bSNnq/gPUfjFydcxRszhOQHYAiKQ7iIIozb15wlChxEmfy15+W
ncHZsZNlZ8fI+332wloSxe6qrnq6qp4mm/rhnCXNlHUrHw3RO/CiL5r639+h/0K++/H15d27H4yu
uBR1VB6KMtOjKvuxzuZ3Y591/2r7/Afodx9/aBTfsmR4N6xt9u/vrLUfsupfXlGnzdz/69B01Yff
37/71Effv3N/0gL/F/z8//07biyHscv+XWfj0EXl9+9OY1wWyTFb7eae1f+OKSoiEoJEGAzPYJr5
7l0NVPn3dznoz2izWjqzvJZVMej3WrR289275FqUaQeafsc19dA1Zf9huED3U9e0WTesP/XBjkNj
JVGZ8UWV1U+9wKn09+8Q6gfo51P/rKnWpNl3Px6ApD9ts4+SO9eUTffdj/txGJr6ECXZn7biyiKr
B6vYgBgEwdDv35EU9qetnv767sfPGelPm9vZMnz347PpO+n8juXfVb+0fjc0Tfn7DoQJaPlTa7WJ
0s8L/5/nxz9A7xv83PrPQaVGcVb+7agqn1LYMS0Gu4uK8o/A9BlMvPeT3Y2/d+zvGzxR892PWpF0
Td/kwzsrqvt3VtYV+ffvqH/R7fD9u35Yy+zf+6ZM39Cf2iTRAOwAQMxg379j6De00aIOTPLvfsS/
fwfs9vz9hkYf0PUfxnpDuw/WoQGGEfINp9tRLNdptgDg/x7xnwPte4Xevdfo3e9hCn1A2j8Sdz9P
FitLxq4YVi2qo/+1CMQo4vt33wKAn7Lam6FIkMSXYxF9MxY/6PaMn/1P2r2rgHqXrHoGSxAg3wlV
WzZrlgGjl/nT8lORZO+iOn3HXp7n/HSk/y8g+VQkT2zum+Vvh3P7QVTcLMiXAViugHF+/RicsAcV
SLf+WLh74zzDR/HSsOCfbjlXwbmAV/L8fN9zrPz8i099Jj1fyKIuO3eYZaWmYlmOvYJju/fn883r
C8vuEQ28IcFnLP8IwG8/UVbSsd/3piTCNUzAS7UAvXJ4wUZdgYXvJYjBfXjCDWJPNAuRHPP60hLP
vlgpFUr9bOaX/f5+FFdaT/ytAMdVHWsdTzpbgZ9cEkmZwqrsQ2sPZ/6+lEUXjzyggHSLStcOX186
iyPiCZ2OB1zGuEqcF3feX6hcovJY22A05ufzY6/49yBzpgk7QdRt8iGIRCg6mHnmnC/hc1SW0Jrs
6wtt7GvDZC2ZB8bh6JAdtzS4HDmo8KGbRLUkvDsQyS7HbjQnJPyoWNpFYPmxg/ndceFtFfdp+iSp
204mXl/Ww25Pt9kun70LNBzoaUZ2HEZtlyJEz49A4Ka49401odI7IbCXTltOsrhv41yNIN7kAnF/
wYFCgaHc8dcXbn8JDbeErPN2aRlLmIicxlKkDGa2hFRYmBA6hsqTwbIt5M8By59uDBuZ+9seY/r1
hD92C6Q39j2E8+n1pcYFGVfvrazzeQ9dJ8i4nnbnScbwkoGWyYR29kQM8MBye7m4VzKbL7DosNlF
3aYFYyX29Jjs8a6swO+vL1gGc/OJLNmNJ06xyKYAL/aGs5F0m3FBYi94xF6ESLg0Z+4se/y1Cfkl
yLSb/NBuLH3eFRAJVTakOnLw+nLkLoGnXE7sOfBY0/EO17hkZtwjMkiSTwRB8vS6q9N1FHvWlE1p
Zi2TZRd5z/KwbMqcPKvZlvAn2nBTYLeVzzsGb3EdajbI2U6Ttb/Ix/2MGwDnKp0j8Jllb7gNPEdW
aWOawNIOx5qatMdlgTO3EzRyMndZ2OL1RQvk4/HaFMJ234WnjnVY2eZwT7ZczhUbNPDCOePNB3+f
g1Za50y8jVtTOO7JCmzOjQlbsOJ7iQWwnDqvLyW8noqWhnmqHyV8PF9Jk1bNchDdO2FZyCC5MAOl
toYp5KENPeQWoWkfjF1F9RAP01O8MPkJzuk0S3evL9TjRC9jw+/nhA9zWOUcRVQUNpf2q3IXxFC6
RAUkR1fHq+eLUgvkYYCzq3nv5OVBactqsR0qzu6sDVH1+tKcafg+HPTzwQ99YfVvzQM6ERI+YRKO
ocIlXHIIamoBA8bXT+tABhc2Z7n6eBciqX5EtcjdQzroImYH0EsWV0PMtNlMx51FUccy3Ov3Zj64
zE6+BzltHK4+zMc+d50ec3SAtv1YkiXqn0zNOPvXaS50GD04wiRxACGyzEfxiKCGcyF8ZD/NqL/l
xiVUhpuHKi7FuLeKDEd5jcSl6EusR0h5IfK2v45lRxTqQ38M8IjFybxvX18IWsaruFe4sHK0Qw33
8aMvpsOqSrZBX2s+nFfq2uBYQFDELb2TN6eUrYa78ekkG7fjLcqD1IEmvI7T+fVlguE87Wci8dWo
3MwTtO/HqNISWkJcd9DwEaYzRLZlVCCO2p6jZ2lLjvveEQrzJO+O2am0cXIolEeB5K8vJzPQH3Qa
HHyjcGMxMhOhFWLEq9RWqkRtqnV6xyqLMciQdtMjryDLywKvmkJXj469Ur7EW110HAX8yL2+WIF6
dxFlf69xjFbQx9Du6OF4i9dBmyULjjMokOmZiyHZ3o7DevFvAeZT1YlxI6Y9Tic69Wg5bdFhJbTX
F9scpSxIMZZXkN7cuccqV1bRmUI8anRM6WHJP01lFu8SPiOkNoQ1MjaWupzUO29oZ91f9cxRIoJl
+Nvry3ZU9aM1mOLU7lqUUN2Oi3TfiolYjoVdmJyuWhb5FGnU28lH9220+hSjN+4OS6T5cKCDxvNU
N0Vxai1BXqAiGCsfmLfr5Yk8oqwct0kUoQbO9XJUTpnaxPrukXabwWD848ooD0QbwkSsxxrlNSY7
oTACpyWLPbbXF72GtWmFA56FDaPJHa29jgGGWKcjlK5krqm3fGQ1k6RmDmTSVcRM70Gr1N1BH8jg
+tvD59pjjCmUWlmvL7EFaetZ7hm8CwVqoQ+W0KktG15vSa76el/SEdz5+phOw3niR3YljqYfMhh8
MsjwwE4micLbUKS2txkAIXcCJfoqzQ/wucTzfZNBGZ9na13UzTVA3Bsxb+7BbuNTj26+3WkSBgM9
GoryHIzXEDWFhscxKLGL0r++LLp+I1o46gfSYlptQeqmNCl710fkCIekqtCbo7i0QsN1Q0RTkZvc
NKZhF1vYqDwUEQ3TtJnKFWL7BMQQBhWG0tllbOefDw283Nqagqxe3U0CXCNQeM/v3rgd3K5tNB8X
wcTsSvdBtxZ1TspyR5ZRakjb/bR3h9eXBG5LpcXXLA4LV7ON08PI0a7LYbxUR3+8R6mOGPYSoVEw
Il3RRheestpYJc+FttKhb0s2PNVbp6Ko/Pry6DCmE0HJydB7SptCrEavEUkSQqQt7nQY5931Ql8E
GaNxKXZOo7+fwKw+ESDrrQpzNlp7Uxc7Tv3jsQO5nikeIfxQ1To1McLWDstA7hl2a2nHrnYLdm+p
CQxoRh2DUx1MMikmxIt0oma+X46SldtkreYeYVpZ/friIu2ECUtd8Lo4JDxpjRI6Rn1UoqNhu66+
rW6m0gcGlEYLPi4KSaZOY1zEkS8fKa+0FWKVfXRY3W22AXqP+ZKOOKtqHTM1DXUxcOqipVFoJwCq
R5/JcFa7MzCymfBmmNUQHDCYa1Fune7qjQ6IZc6HVKBYxRaA3Q4GpKiUrvMEIfHDsJ2nOhqNznmQ
ruNvFuX3eUnE3T4NdUwILk437WdKXEVqk3uHP46+hdX76araN5CdsQLz7rtaoRjFSIfdKGLG/RSO
O7QLV4QZ6VyeqHPBZDVuXS2ERJdthlKHmekcK2qWqdgBIoqSbNR7ir2+BN7tXCoRCJ3iebdzqMfS
DFE3MHjW7hq0ox5pnTy4jIjqmtwdL1W3dxiRcpfrliFG3B2yaYQRaM1EGwMZ0HZlr0RpzLpsfuqS
esK2uOE3u2VcWjXqsSBqdr24D0WQfSkpYUXnJvMIB6X7+8Og7joGaVocRY8LBVOgitZF71FgmBY7
dqqsCHnvTo5EXkmkmUDOGCTKzo4h7EPjZm0WpCMnFV/VFM+O9rrzrlgcP0aQ8UWUoVBgt2k8iilU
OSW0XAWLSkzYnTqDYeFLZ0Sdri8OcjsJcNxayjHNPeR4msj1pvmPQcFueBg9xlxB3VV9SKAaZI/s
eLaRWqInZ6ctQa07qo8XOhTHzMmcePyKzqfR07Gs9/Km53vepTsfVCrJoWayo7fr+FXzoPHeVwC9
QrAjG2tVemfvLIVaHnK/94sKD6Fb1p0j0kwOw61hPD84HhsCOrTLaXGF8Xi3pRhhI7dNKScupTDM
b86zqvHzU7K0y9nj8ka4HShQmeZ9BopQUOaQj/0NTy6ab5NpRbPUHpCAeKrjQmEsP5Pr0cUoKZ86
6WjjCsiAxXVmhLSfRFCmR/XqReaECM0UiOWxi2rbg0yCzTvCEwt7AWySrw6nQ0pho3Xto7igXD/l
7GpmaEq4Ai/UsWa32HqLpsaYeeCZ26jckpE8HGH9Ptny2MN06aA4o2pk7pGP47CRSmdYx2qMIhri
oCyw0ZKzZNEHOUs/eXoYEhF/2SKDpqjM8U/uTiv2LTLsKsRohMU6xDokcge1y2itUx5tAnKFwgxq
S6k6TCJ0q4MMlOTZ60sPZSahtjfvdlfwXisygx/xzItJuPX6MD3BEQfCY4RNB8rlxFXqlvZUHrBK
aXaYAjlYhyGibsejeISAT52WmsMWrdREcRy9b+ura3ACSgRUtN9Vut23yDOvBMcon/CTR92yOT4z
iZY8AI8kYTEukXLqkQ1JSGC3vrqqy10hS3cXoZ1VyO6BLNJywDOQFBPxnkSY6RIT2Q5wrbe3qhXw
G0OWN94NdzZdL4XR3Nv5kVJ2ewKM8hhLmaaqyqBL9hgdj8lUHSuFwuuHpGMYP0ECLRFHbL47xawj
EUt4ZbjlZcc53R0ZQIAyLLQX4Faz7q8vOd8/zh2jqtjiX52Fdqz8MHAwlht3v3FIlxDBjBgPGaVk
Q3M2duVWlcFOzDfyFKMiYTwILX6cixRLzmeAEAc7ceq8q2831dulHGc/JA27qKNqVzV85c+Q4Z6r
EnVK0/ClQT2PA3oe1a7mpkFP/ZVOFewQpbfcV31QqerMgvq2cmfP6uHQM5ZiOTJbmWM3Xh3Cn7fL
ajEaRkvMhuVrDUkZRUEwNikdBbGddo9FqvR2t/eLAq8vCsjJgGnfA/9cGpW+ht4BDk121XgBVW0W
Vm0ZcXlhNm4yZtxM7HnMuLFzYizc7dkF58Jn9wqH4gF+fQntdojRcxvWdxaQukUv4Fnn4FV3zUXj
m1XfGlhfwTG+mTVWXHbvu2DdVHCD9AOvJ02U6UGZBHJWIh5uQBdUt51Nt3WKFfHn2dePzz4DuaF7
bmPPeUqcDbuZ9VuzGha7aHaDPF/r1ARiiO+/lxX+prV/bcN7OQReWtqiO4bYuWF5YdNuBROnweP9
8oX03kJlJpaVcX+2CxVQv3mHOnTTNpSeLcxVu52mKza8byFgv2txCqtwC32T1ewA3qS+O7y33fDe
dsBuTz1urR2jIZyihzU09yClMEVo7c1IZOAY05sYYy8mom2ygFwDtBxTkdmioxXDHv3sK/l5XK8v
z5Gl4hWJPWUMvLI37voU+/s19PUt8piR5WMi9Pfv7XH8eHT1uUk9pIirQxvz7dERXAnwBY+AQ1+5
ReJhDFFXBL4ZgudINnZ+rI2amM+RMB9Q8GEccCS5Q1AR18ibSavcH87wU193BdkZvV7jKi3PFbMC
G8K/Wl3GAOaaql+q90tD2Gf1ssA4phjQ4udImdH1iDZl2VVx9hn8XIzaf14X76CUCcBX6gPEoDir
b/KkpQ9J5Gb2ucbF5h+j4zc2LMtf5H6wYbKq2wGm8IoB7c4xXAqme8b9EYn2yNkF9Rv12F1FuyLi
utqyMyjpY69TsvJ41upgk7fIiqJKzJ0qWENUPJYpdYOT+4Hd7wW3DU6wXHpls5z3rZSary+m0lll
SlAxLhHMUPsmdYcDYg7d6eal0Y6BICOHiJWaIBQriDVM800KCPSuB3vkPgQsci8jFrnUkYlcQER6
/pE8C7nwnuU2vMdrd9thTgyUY/Q5gTRyDu+PqGofj+7YX/usbc6QvM6KcMdHG6K1k8ezHF9H27Z/
5oVGay82csyubvgwLzTpOZekVtZQLXbEpW8gjb5oycDY2zpOOyuF7kt9ORv16A8mG0LMzQqq/e20
JhTwwvnEnxspXaMp4oednmdiQLuL4tmQUCj6gYrQ8QGDGj+h5DXptI20kkmhjH5Qi7olBrchuiGO
UC28NSDL3F23Apl3hREtJsex0W49l8jT49E/nJbvz00g7l0M4S8kXmIyPuTIBT3xi3AwzUW/RV4p
sbHAxLLWs9fXF7zfZaKLMTOi28TBHMDBq4NNp1W/CDkE0715VZjjmRrtSpGGajpyWpXk6wXVBT7o
E8NSZrzlLrd1OAEvZPWIM4DHmmL6SK7KLajXfjWkqRTtg+J4u5Zo7yepZeneurLYgO1cYlG2qN5J
winAlGJSKkXOrevRV0DOqne3MxQpElMJYz6tlwsOH5AEhMwjiN2beBbCmzY5nULLkIozlUjydY5I
HhjYA3cQO91zEmXwnaEH9wOo3+ahOnvm4s4nqeAEQBVvlc5MLjNW1IZ4waz6LZnzTtNm2Lov8PP9
wJWROM/cwpb40Z+lQ+cyULNjLZABt445CMJoHYCA1jK79mGMhBH3uJGDfH8q06H22Ps41mpBE+zd
Nhl0h5XkowofScOZt/bhPQKRYeBsd3x9MZDbvpB30I3MpHXn0yNVaZtVaex8YtIyruhSrkPNO5He
dT65cIqjxk1jdBvnlD2o7DW76iTMUvMsPTzXVLmMnyHBt2H2hiLBIaKJOGjXU8lfoXLMaHml6GOa
bMfLsO5Gvz7fGFlgKYJb5JpAURM/xIdQSReoYIHddvB5qvqzCzVeCGrz4KRRIqgqPDMseFBbVYWL
7YIOhN/jUcPu84RN3K5TDzVvBF0Sm7CVXovMup9jHo5BhY/zXlmFKk2dHv7hTqyZbjaCIqiO2zr2
/ihQ/aUSafxkB2g21rRoOq3guYRlMv4Cxag+UaUC88xQXJjXl4Ns8Oxutj2X5aCe2LL8wHghE4+p
q0tRwgS3K+TkN0RfU2qPpwtxGsXzg521W2iYS3jAdnvZ9/WaotkZ5NNMBSQnF6/3XCJDmdMZJYab
x6MJesWC9dRC0jiFIHcnDVyMjy3ahNzlkl7PRsGjIbXLziIVEyy9P5M8yDLQuXyoinrm27rBb3Sb
DfxM6jy90EOhuEpUEeOlsdM5I8HkgpGz7QDDaGQ0sZp1kC3OKRPPF3Det0C0jDdunffh5Xpo54Dd
JwK77VVKEB6srB6vpqCKe+E+nx+PwDyAkDyhPZlsobKMJj1fIXXir+V2Kq0+Hmcw0lQeyNhOpxv4
3UFETqJ6aK03jMcxuWYhvFvQSD4dfWOzhQ26wTy7YXxD0klyxWFUtJkW32ePkAkwPX99gZzLojzG
vutcCkfJjJEd9nxb7fsBsNjsfNj69FgLO9eHQIVppCf6/vAW5TTD8uALEIHp826EdAVN3XoDTPxZ
SxF7QJSi3Vhq8W26rMmuwjLsUrmofE3n9gRamSChpWiv5JHZQk1OxfEMk9kla6Vg5Tzlfs/Ynff6
wkgECZxPCjf5CB3rMbFQb+VFTcHvPqYNt9S9mSIzRd7Ncwj3CbblVBNrIMsHXHQD73LoGipDlkE1
IhCRrjsbVFekux3Lnu22XRePLkRWVxgTbvchH9mOIOdMO7VHeid7q5osdLuDDNSy12uspscAalTE
7w3vOevzB7Iv9F0VygMxGyi1gEkNcpxr0LiHRpGB1VPJmMUdpSpU0AnGO+UFQXYBuZ5ErL9C3mpr
hr9z3I6VX18WzqtpyWpya08I562H/aN4TMUtb/d5kZT74bS5UomOacyJeVqIvj0n7WBzj3610DsE
yNc2H/1sW6U7iG/CwhxWmMO1yfJx49ZaiSps6T3bm17yiKKI0qYV5K7+qoBwmq7uPQy560EXRqEz
zzQIitYuFba9oY4Y6C0Zj7S6DiNRQZfD5Ehwfgo6eufEHOcbRjINh/s6RYUIh5iS52wQXRm5AqFV
PNFFalaUW3axpBSmClnV6wvJHniQtvMBM5UY8Xe+fgcm2wrvIWFhDHmjvBGsqZ0UflNJvApY+qBc
s318M0sMwnJZ1IgISVmjQhAQQy47OtOxYamWDj1Zx8EzLoMTEa6mYmUn5T2H7o7krUtnfp61M93e
EsJfjq08d9o1FFgUYTat4vr64gzD88odEmyFo1SXQhO5WrZvLBVUQ8s3IayDAk44XC3clOfxYtPM
WTctJ5UMglBJ+O6VRzutGvIeTUWwQiX7XCVwJiTPF1/lz3dDw+8EqPyJNkrYRQVcJFEG376Tw3hY
H7Bj2vs9PeT5UdphCNTdBEbLxhMeg4pr6/f668uo5NsZuCC6Tfw8TtQtsNCHJbPNsLD0lKnrrCtG
g2N3QxSmwTTRh7RHo1jcBba6c9fDzdjJ5YY8zIQTXl/4q3xiTsKV71Jlr9mXVhqEsFYzofQQLjjQ
qbRl5aIKXHFuH31x4yNlLXqVHvFrtFNmTHdU8pKdFdzaA17vSdyJLGbWugS3/AwfIldUOTKk4dRg
45tgXI2yzWMLdoXr3krkKhlIOwVlWHe8dtEOv1ghwc39nCu6AOIbx6Mdid8vVqpdeUBYQlMRKSU3
lfawTfXB3MlxPddlrHJRxxhs2y3JDreDNS05TiZDptkZ2skvy46iQOzle1RkrkR/hOSNvsZpkpzd
rYxcEO0QRw2MsqMdTmgc1VTdTjbOJEgXVHGCTUfN9tW9UBQ/we8rvaw9+foiEqkTO/qFvJbA2kKE
u4eBj9ohE/aAjSK9zVmPRDR9MRdvpGS0p/uFY6OL3N9UexavUoYM9RkbagUndq8v6O7SrCGUYi42
y+kZeRjR0p6Cw8U+3kdy6ELlmqeqeFF4B9NDykNmKe9YK9icKlbOp61yIVTkxKHZP7nzw0rPRlqt
GDzRJgHB8dmS4+22Qvf5QXeky5IB5FB22B90qiQC23X49cLlA1ycCZJmrBK3sFVjCZLzAZcBmX+x
gxQ4BdZHrJooI9I3KF3x0yPN9+yJGG+WHJrXwiyXejiEnASTt4e9eYuk3i2zzsxj7CGAHYkbiG8N
WubeZM7H29lBCQGzuDWrRoW6NzJ8jNatB2WqDlLsDFTnNeEYh4oJuEK0O3pYuw5dPguVssYXMDMB
24WMELtdyHIv5MLlmCzaXW58gbcAnx/nkVHOaOb2uW2S1zvB+erDCi7z0ThnUBpfrsHOFY71RWCl
JUWgBNht2rpp13GHiGOFwKEIuNcPEmFeWJMFaM1XA3GUrVLikxQHFZ3oKoESCOGRltHSs8RVpNuk
QTpyZgni24Na3PQQtpCOrI6lTQrP0aJtHbBFzC1CnT1Ude745TYVqNgXgFNpDXqUyqbk7onIu/tu
z4+OdrwyjW8Duwkznrqy6pmHdVf1cHrp2v2iRdS413h6OIrL9JgVLiubR1YWLZ6VZ9W+HdZTD3IE
ecTCDDtdhnop8sPy+qJrgNrcEyG1LiWfu8jxBLimDfiOo5CzerW3QNqW6RCjmaU5WGPebS4zDI3P
zt3NyjQtiwWCh6j6CGOgUhXo8joRKZ7FfSTJRyabbPiQbcj1htLbQOx3l8K8RDxcRg1DdFwb70/a
zmX3W5NFt1h3RQ9/ZIQEI/i1B5UqImBxK10nbtpnDn3kOos0V+iQ5eh84ytov+ZXqnP5DJQrtwxl
qpnMZT+8xOHw8GamDYcbCHscCCkriCHSfg5Mbl90KasgkXmHbVyx0IJz5zVwVH+hbQmXr7N6szmP
LVjS4qPqXKSlEhDE2B5MGb5aDmrwjYXTry9FbvEcAuCtNq3yQJsaLXWcF/sJVG8nO7pdDcQiI49k
rmR935vMFeMoEq9dO0QE6ALm6YzYU9eLSvFcU3Up9UgKzE2Dh2NUxR1IUZEy7ALptMMnXY3Krkj6
ayeyd3dEI61z3NLHIeUY9bfJufAk4Q7tOZqN+uSCGomsYVxz0UKfH/KWe+oaVY2CwaC6I5ZObu5p
qbE+IIn3fUjFxoF9bANZmJ7baN7+1uDiQGaUSKhEVJkG4Kc9HpBJdbyslsXqV4k9WEQb3xVb3umw
TxS4q3vcuckIWDH7y9wk+JHdiWVORjXs7gZFYLvoYJnKit3BSHf7OV0EDRBIiSSXeeCIHfs4IrJT
DzFK3beWYWVnJ3Cy9rjagEdEY5/N8lD0455/+kg5okvhlJpgKCCSJ4YG7HWlEwmhg6pxIDKSQ44g
gp1h30WZC9OFi2lLGsMJCla2uiOA5laexijwMu9bVQ3OAXwfYM48gQy43BspjJ17H8V1UIoWMeKT
KdKJeG0F9J63rJdxNrzncjQr+PNFLEVMvTO2i3rlNW/DyjzHMLlUxJkeQQxhXAPjnPrYkTzCyO1F
nwnWux9FYqWDQulIvbPOjXw2o4yNHl4QtqKTW/U45fOYGfCdLdNN35x4aI5N8/pycx7kozsmftuo
MKPVZnj0dzuZeMRZvdCSGPSHDtaUa0cSXXB2rtLlTtMufkiaPRQfCXdWMA0vmyRtdqA3VZzyUVOP
y0jtguQ6dGsqhu2ZHaPHMtMqpj8efaeoEd09UEhuSYug8YOhzoAOi3Xn64oiyX68VtTSgNi7nvdJ
DKb7NVLiSGzb2NdXM/IOIbwYqGeYUugq3d519MeeugYgc6nKEOxBLtWUg75DpECorFWhH6FWAPZx
LB9hvXieLJdNWwR1YviCm5klnGXrfPEu83QLor3dFFLfkAfRwOhJfUQMBYoKdi3g7eS6J2/xfH+P
Ad2oTeSUoxAkXnKcqOrSZLFMWv3jMKumNB5nacuXJK7OSV44IdZeERt4fmP3aKMWFClfz3mNlUHL
uLWkP2skh3LZHIIlQ7csxlDJdj8CNqvGYvO4ibdefPjjXRe8q4g/PKhj7Sw/us0NGg416w9ENxLX
R1QEuNeEwKesi8vnhp2OnIKsGAXmFH8uKQCw2sC9SuJ5RGmkIrqqiVYWtrLSiEIZ1x2t2wkm30q8
MJfZSq6nMgYRaScclHsGbUlnKAkvWizXTGPJzFtvmq58zw18H+OAXCagxPeC+nZluH3jJAa/SswY
gRmcHPYGn0K0aTtg1sO8NcQXGhFugWebY6BNhXc5uidy6TgYHgEdV3cT6SA4Bgcj9rzPQ0gwbrjc
SRLjzCqsokRm1POc7VGQAWleyN3WmJ3qwF2jPYg/9c7dlH17F41aBBlkK5LBH8z2MDEuXJjISZZQ
v7+UJ1NOBeiY3kWFmtLtYAFGyQciFDTVeFHD/ITfN9WRLfpiizf1fC/pHj2VxAj52P2EyAMO1yVP
tzOko6mUFSe8H+nD4ErcvD4uD1p6fZGl9XqxnU2LTViHT6Xkw9ukqiCuyUmDwzq3i6GpP3L3xtpy
BSKi3XZDKgo+N88V20uQBI9T5Re31smx1xeYwZn+kPuKVSymvmkSJi/atpPuBxt3S0R14cGf8NK/
HUtM1dduAnNzsyhHW1uVOi752YcpXmvTsQ/BSG+AqUlbvBWpu3IHA+bFpafwA7Mp4ngGlM63VItB
L2SaO3pkV8K8hlHTgxTUrusZG+Fav614Wi2cUJ9eXw5mj896yiLJPlfZwTl0wnJPFphpJxsS6bQ6
2CnKHtTaR/j4lmyC1nL3S38d5sHYHkxjGgGWqO0yZ/Tz6tiFWoWd5QNfdV43TO3e3TZoyHn1Yid8
P7GWsPQOfzrdN16ZrlkWYt3NXJwi5QSNwMCYjJV3RYTT5hFwZ98sFZD7e5QBZPLoZIQl7lx3g7CC
ZtXFhNcoCJed54HKJx284VJa/aW6dnqc0Nk56K3zcctmwMFS5QKqGlu6FkjENTx+k0UxmZaY3Z2u
uAecqDwGaK21Q1GedjFLoXS5Bf7k1IsKRXcMh+FD42qyp8hCuZFeDOo3GDLlAMeVMthDcpVz8qaV
ZzMjtOPALsgdYcWuCbY9Z95IzcvXW3COjylnYtqU1gc90fiGOYe+Ctm4iby+mItMtnK70pd8rVfJ
e1LflsFSiArRpPXx6IzKS9hcySzT0lD1WD1UvIseKM+lcuXj9fIasI8bnWsbT+/XDRelU+IswuX9
RSTLcY3zkeACWf73D9BPN9z+coful9z0zSDE9+/wt9yr/9Fd3z/9vPmu749uLn7zfd4IiQIRb7px
+9f7vN/SPTjdGpr2ux8PUdl/YjPPF9+l/WFn0N9+h3b8XoywFMOX3aD9q68RGH3uRcLecrv+X/D2
r4q+3dkwMMyb9PrI2W86/f1N/W/UxekzF5SiUWk9N1B8tPfrc1szPt5BxQEf3j8e/P+8P/Ifu6b+
qeACabu+ZB+EfS28CBoB6EL/5ljysaZ/K76YN8Prg0rfCGAfj/+/A7FzkVyfA/kW20yMcWjHASSC
rwUZ9QQZgnzhNqUvBdkvar4ZYRgO9CLgNyagnyD2llF8gNhnc/tXbCqK6m+wPa59SsG+1sso+dzS
+5bk/1eqkvcqvtnD1DN54vSbfPaLh3+/LflNPgId/GSuv91RQxQnH0T9sbP+yF2fMftXeutz/vpV
0zc1srISWDlLf/LEp4L/51xNMgB/+Cer4j9y9mdEvMndp+iS/e2+/nnrIpD3Z87+E3ejn9qA+Rc8
/jmff6TxG9udojQt6guIyCDjf/h5Y8uffE/TQMlP7l7+Gu9/tiT9aWBvbPSllcMbgcdds+SepWrR
f5Ps//Ogn/L+HICf2vvcVdEwAPcKdRSXWfqH4//DMuL7d58KzX8Rw3+G4ue439z0Jzg+6wqM/lQq
/GpA/rZk+Nyhf07Yer+v+n9PzPpZ3X96wPpUrfrJFu8DFsi+LXD254D4f2bAeu/K8v+yaPXLoL80
VFFPYfDnws7fFar+kwH9Q58XojbAK/0QDdnf/ICQjx4p8zVru1/6RI9fx/VmJgV/8nlNXxaq/tG8
9wsfofFb3ov+zWsbHzT8MtpLfhnr/SR6Pl7LOkXF8yk2H1T5n/fvfruK9U9aG/2wpPse519PkQn8
+Qgl4u9nyR9p+wWM9/MLpH/k57fp9aF+eLtGX146fH4h/r3UTy2TfiqR/FNSxfuHJJ2ivp+bLv1S
yP1pvvjD+EMBlKKfLgy/Kmf84XOgfh7iF63MfCZ3/BFM37iO8x6mf6DTPxwwYNp0z7csr31TzADP
f3I5/u9AzEdj/JLghmBfgZpPM51Po+Znvf4foNj/+1+Czre6JHOa0wGI+tNrMn+EAYyEvwYFX57d
flX2TY1+ns3cNQL54//7Esw8H9v5yWuZX0qp/8m+H3/C7V8GAILg36a8+Q+N/3aPfrKU/auM8xtS
EfQvXYKD30Ir/ioXectlvo+5yJddxv/kkyL/OTOwz6IuuT7R/PWTjwFFEfoNLsD9qus/Ydq9yY3n
KC2ab8QTP5IlGV/vTZSggMHeVhr9JXf+Rt8v8ChDA6r4No7wxdXUz/fmvbkO/VB/SQZ0Ooh/C7v8
GtR904UJ6/2s/AsrE9jzjppvED4+VvdvX5p4WynyAT1foNJ/c23ig9j/lYsTT77zTUkm9kxxb2Nw
/x2W+QUAxT79/QN/jM8vWTr7jD7/9HzYPWV9gLpz/Avcksa/TT78jb5fVOEwX5EQ31wRfVVCfOMA
/mIy/M3b3775cyjqzVDkq5x8AyTW70UVQBTyuS8W+WC2j078/RWn/2gBDFfE5afD2Zfa4vl1Lx8c
UWzvYf+v54rF89LxhxefttDvm32FzTAkzjGaIKMUI/EMI362WfKU+4cXsv7TIO81Zbss+phfykDr
vzLyZ3/fdPTQL9j+E/+r2SWr0//SWD909g8d6C+hGP5UMv2KGPzp+PsBcX968vO7LrL/ktk/9PXP
NPuH5IK/r36Z39OnL+HOnw52n7P30yjPMWe/mvi9wd49Nfr3dz9r9Jvs/cGQHx355dg7/SOvgXjy
Aek/Tx9w4Jdp/lEEQX610wdb/a7/H36afr8V+eHgTyJ/kfDbrn7f8IdfI9dvu/vl+E89fl6/T/Tw
08Ff3P1bs/42Q7B9n1UAOL8M8ecj649VnzRdWcT/hXT4A/RLr/8p5cME+BYy/utJ/s8lPifytxHU
RTMIK18jC8ZyIqdyBEkJOMKiP5flV+U3GRPXdNl/X9Avbz9A/gfo4y+++/H/B6KTj3cHbwAA#>
#endregion

<#
    .NOTES
    --------------------------------------------------------------------------------
     Code generated by:  SAPIEN Technologies, Inc., PowerShell Studio 2016 v5.2.128
     Generated on:       16/11/2016 11:51
     Generated by:       khanm1
    --------------------------------------------------------------------------------
    .DESCRIPTION
        GUI script generated by PowerShell Studio 2016
#>
#----------------------------------------------
#region Application Functions
#----------------------------------------------

#endregion Application Functions

#----------------------------------------------
# Generated Form Function
#----------------------------------------------
function Call-new_user_psf {

	#----------------------------------------------
	#region Import the Assemblies
	#----------------------------------------------
	[void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
	[void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
	[void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
	[void][reflection.assembly]::Load('System.Windows.Forms.DataVisualization, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35')
	#endregion Import Assemblies

	#----------------------------------------------
	#region Generated Form Objects
	#----------------------------------------------
	[System.Windows.Forms.Application]::EnableVisualStyles()
	$formOpenHRADMembershipTo = New-Object 'System.Windows.Forms.Form'
	$labelAuditTrail = New-Object 'System.Windows.Forms.Label'
	$labelOpenHRADSecurityMana = New-Object 'System.Windows.Forms.Label'
	$picturebox1 = New-Object 'System.Windows.Forms.PictureBox'
	$buttonExit = New-Object 'System.Windows.Forms.Button'
	$ChangeButton = New-Object 'System.Windows.Forms.Button'
	$Outputbox = New-Object 'System.Windows.Forms.RichTextBox'
	$panel3 = New-Object 'System.Windows.Forms.Panel'
	$tabcontrol = New-Object 'System.Windows.Forms.TabControl'
	$EmployeeTab = New-Object 'System.Windows.Forms.TabPage'
	$EmployeeList = New-Object 'System.Windows.Forms.CheckedListBox'
	$AgentTab = New-Object 'System.Windows.Forms.TabPage'
	$Agentlist = New-Object 'System.Windows.Forms.CheckedListBox'
	$Loginstate = New-Object 'System.Windows.Forms.Label'
	$panel1 = New-Object 'System.Windows.Forms.Panel'
	$buttonLogin = New-Object 'System.Windows.Forms.Button'
	$labelPassword = New-Object 'System.Windows.Forms.Label'
	$labelUsernameADM = New-Object 'System.Windows.Forms.Label'
	$Pwdtextbox = New-Object 'System.Windows.Forms.TextBox'
	$usernametextbox = New-Object 'System.Windows.Forms.TextBox'
	$panel2 = New-Object 'System.Windows.Forms.Panel'
	$searchtext = New-Object 'System.Windows.Forms.TextBox'
	$RadioButtonHO = New-Object 'System.Windows.Forms.RadioButton'
	$buttonSearch = New-Object 'System.Windows.Forms.Button'
	$labelUser = New-Object 'System.Windows.Forms.Label'
	$radiobuttonUK = New-Object 'System.Windows.Forms.RadioButton'
	$notifyicon1 = New-Object 'System.Windows.Forms.NotifyIcon'
	$chart1 = New-Object 'System.Windows.Forms.DataVisualization.Charting.Chart'
	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState'
	#endregion Generated Form Objects

	#----------------------------------------------
	# User Generated Script
	#----------------------------------------------
	
	$formOpenHRADMembershipTo_Load={
		#TODO: Initialize Form Controls here
		$panel2.Visible = $false
		$panel3.Visible = $false
		
		$tabcontrol.Text = "Employee"
		$AgentTab.Text = "Agent"
		
		
	}
	
	#region Control Helper Functions
	function Load-Chart
	{
	<#
		.SYNOPSIS
			This functions helps you plot points on a chart
	
		.DESCRIPTION
			Use the function to plot points on a chart or add more charts to a chart control
	
		.PARAMETER  ChartControl
			The Chart Control you when to add points to
	
		.PARAMETER  XPoints
			Set the X Axis Points. These can be strings or numerical values.
	
		.PARAMETER  YPoints
			Set the Y Axis Points. These can be strings or numerical values.
		
		.PARAMETER  XTitle
			Set the Title for the X Axis.
	
		.PARAMETER  YTitle
			Set the Title for the Y Axis.
		
		.PARAMETER  Title
			Set the Title for the chart.
		
		.PARAMETER  ChartType
			Set the Style of the chart. See System.Windows.Forms.DataVisualization.Charting.SeriesChartType Enum
	
		.PARAMETER SeriesIndex
			Set the settings of a particular Series and corresponding ChartArea
	
		.PARAMETER TitleIndex
			Set the settings of a particular Title
		
		.PARAMETER SeriesName
			Set the settings of a particular Series using its name and corresponding ChartArea. 
			The Series will be created if not found.
			If SeriesIndex is set, it will replace the Series' name if the Series does not exist
		
		.PARAMETER Enable3D
			The chart will be rendered in 3D.
		
		.PARAMETER Disable3D
			The chart will be rendered in 2D.	
		
		.PARAMETER AppendNew
			When this switch is used, a new ChartArea is added to Chart Control.
	
		.LINK
			http://www.sapien.com/blog/2011/05/05/primalforms-2011-designing-charts-for-powershell/
		
	#>
		Param( #$XPoints, $YPoints, $XTitle, $YTitle, $Title, $ChartStyle)
		 	[ValidateNotNull()]
			[Parameter(Position=1,Mandatory=$true)]
	  		[System.Windows.Forms.DataVisualization.Charting.Chart]$ChartControl
			,
			[ValidateNotNull()]
			[Parameter(Position=2,Mandatory=$true)]
	  		$XPoints
			,
			[Parameter(Position=3,Mandatory=$true)]
	  		$YPoints
			,
			[Parameter(Position=4,Mandatory=$false)]
	  		[string]$XTitle
			,
			[Parameter(Position=5,Mandatory=$false)]
	  		[string]$YTitle
			,
			[Parameter(Position=6,Mandatory=$false)]
	  		[string]$Title
			,
			[Parameter(Position=7,Mandatory=$false)]
	  		[System.Windows.Forms.DataVisualization.Charting.SeriesChartType]$ChartType
			,
			[Parameter(Position=8,Mandatory=$false)]
	  		$SeriesIndex = -1
			,
			[Parameter(Position=9,Mandatory=$false)]
	  		$TitleIndex = 0,
			[Parameter(Mandatory=$false)]
	  		[string]$SeriesName = $null,
			[switch]$Enable3D,
			[switch]$Disable3D,
			[switch]$AppendNew)
	
		$ChartAreaIndex = 0
		if($AppendNew)
		{
			$name = "ChartArea " + ($ChartControl.ChartAreas.Count + 1).ToString();
			$ChartArea = $ChartControl.ChartAreas.Add($name)
			$ChartAreaIndex = $ChartControl.ChartAreas.Count - 1
			
			$name = "Series " + ($ChartControl.Series.Count + 1).ToString();
			$Series = $ChartControl.Series.Add($name) 
			$SeriesIndex = $ChartControl.Series.Count - 1
	
			$Series.ChartArea = $ChartArea.Name
			
			if($Title)
			{
				$name = "Title " + ($ChartControl.Titles.Count + 1).ToString();
				$TitleObj = $ChartControl.Titles.Add($Title)
				$TitleIndex = $ChartControl.Titles.Count - 1	
				$TitleObj.DockedToChartArea = $ChartArea.Name
				$TitleObj.IsDockedInsideChartArea = $false
			}
		}
		else
		{
			if($ChartControl.ChartAreas.Count -eq  0)
			{
				$name = "ChartArea " + ($ChartControl.ChartAreas.Count + 1).ToString();
				[void]$ChartControl.ChartAreas.Add($name)
				$ChartAreaIndex = $ChartControl.ChartAreas.Count - 1
			}	
			
			if($ChartControl.Series.Count -eq 0)
			{
				if(-not $SeriesName)
				{
					$SeriesName = "Series " + ($ChartControl.Series.Count + 1).ToString();
				}
				
				$Series = $ChartControl.Series.Add($SeriesName) 
				$SeriesIndex = $ChartControl.Series.Count - 1
				$Series.ChartArea = $ChartControl.ChartAreas[$ChartAreaIndex].Name
			}
			elseif($SeriesName)
			{
				$Series = $ChartControl.Series.FindByName($SeriesName)
					
				if($null -eq $Series)
				{
					if(($SeriesIndex -gt -1) -and ($SeriesIndex -lt $ChartControl.Series.Count))
					{
						$Series = $ChartControl.Series[$SeriesIndex]
						$Series.Name = $SeriesName
					}
					else
					{
						$Series = $ChartControl.Series.Add($SeriesName)
						$SeriesIndex = $ChartControl.Series.Count - 1
					}
					
					$Series.ChartArea = $ChartControl.ChartAreas[$ChartAreaIndex].Name
				}
				else
				{
					$SeriesIndex = $ChartControl.Series.IndexOf($Series)
					$ChartAreaIndex = $ChartControl.ChartAreas.IndexOf($Series.ChartArea)
				}		
			}
		}
		
		if(($SeriesIndex -lt 0) -or ($SeriesIndex -ge $ChartControl.Series.Count))
		{
			$SeriesIndex = 0
		}
		
		$Series = $ChartControl.Series[$SeriesIndex]
		$Series.Points.Clear()
		$ChartArea = $ChartControl.ChartAreas[$Series.ChartArea]
		
		if($Enable3D)
		{
			$ChartArea.Area3DStyle.Enable3D = $true
		}
		elseif($Disable3D)
		{
			$ChartArea.Area3DStyle.Enable3D = $false
		}
		
		if($Title)
		{
			if($ChartControl.Titles.Count -eq 0)
			{
				#$name = "Title " + ($ChartControl.Titles.Count + 1).ToString();
				$TitleObj = $ChartControl.Titles.Add($Title)
				$TitleIndex = $ChartControl.Titles.Count - 1
				$TitleObj.DockedToChartArea = $ChartArea.Name
				$TitleObj.IsDockedInsideChartArea = $false
			}
			
			$ChartControl.Titles[$TitleIndex].Text = $Title
		}
		
		if($ChartType)
		{
			$Series.ChartType = $ChartType
		}
		
		if($XTitle)
		{
			$ChartArea.AxisX.Title = $XTitle
		}
		
		if($YTitle)
		{
			$ChartArea.AxisY.Title = $YTitle
		}
		
		if($XPoints -isnot [Array] -or $XPoints -isnot [System.Collections.IEnumerable])
		{
			$array = New-Object System.Collections.ArrayList
			$array.Add($XPoints)
			$XPoints = $array
		}
		
		if($YPoints -isnot [Array] -or $YPoints -isnot [System.Collections.IEnumerable])
		{
			$array = New-Object System.Collections.ArrayList
			$array.Add($YPoints)
			$YPoints = $array
		}
		
		$Series.Points.DataBindXY($XPoints, $YPoints)
	
	}
	
	
	function Clear-Chart
	{
	<#
		.SYNOPSIS
			This function clears the contents of the chart
	
		.DESCRIPTION
			Use the function to remove contents from the chart control
	
		.PARAMETER  ChartControl
			The Chart Control to clear
	
		.PARAMETER  LeaveSingleChart
			Leaves the first chart and removes all others from the control
		
		.LINK
			http://www.sapien.com/blog/2011/05/05/primalforms-2011-designing-charts-for-powershell/
	#>
		Param (	
		[ValidateNotNull()]
		[Parameter(Position=1,Mandatory=$true)]
	  	[System.Windows.Forms.DataVisualization.Charting.Chart]$ChartControl
		,
		[Parameter(Position=2, Mandatory=$false)]
		[Switch]$LeaveSingleChart
		)
		
		$count = 0	
		if($LeaveSingleChart)
		{
			$count = 1
		}
		
		while($ChartControl.Series.Count -gt $count)
		{
			$ChartControl.Series.RemoveAt($ChartControl.Series.Count - 1)
		}
		
		while($ChartControl.ChartAreas.Count -gt $count)
		{
			$ChartControl.ChartAreas.RemoveAt($ChartControl.ChartAreas.Count - 1)
		}
		
		while($ChartControl.Titles.Count -gt $count)
		{
			$ChartControl.Titles.RemoveAt($ChartControl.Titles.Count - 1)
		}
		
		if($ChartControl.Series.Count -gt 0)
		{
			$ChartControl.Series[0].Points.Clear()
		}
	}
	
	function Show-NotifyIcon
	{
	<#
		.SYNOPSIS
			Displays a NotifyIcon's balloon tip message in the taskbar's notification area.
		
		.DESCRIPTION
			Displays a NotifyIcon's a balloon tip message in the taskbar's notification area.
			
		.PARAMETER NotifyIcon
	     	The NotifyIcon control that will be displayed.
		
		.PARAMETER BalloonTipText
	     	Sets the text to display in the balloon tip.
		
		.PARAMETER BalloonTipTitle
			Sets the Title to display in the balloon tip.
		
		.PARAMETER BalloonTipIcon	
			The icon to display in the ballon tip.
		
		.PARAMETER Timeout	
			The time the ToolTip Balloon will remain visible in milliseconds. 
			Default: 0 - Uses windows default.
	#>
		 param(
		  [Parameter(Mandatory = $true, Position = 0)]
		  [ValidateNotNull()]
		  [System.Windows.Forms.NotifyIcon]$NotifyIcon,
		  [Parameter(Mandatory = $true, Position = 1)]
		  [ValidateNotNullOrEmpty()]
		  [String]$BalloonTipText,
		  [Parameter(Position = 2)]
		  [String]$BalloonTipTitle = '',
		  [Parameter(Position = 3)]
		  [System.Windows.Forms.ToolTipIcon]$BalloonTipIcon = 'None',
		  [Parameter(Position = 4)]
		  [int]$Timeout = 0
	 	)
		
		if($null -eq $NotifyIcon.Icon)
		{
			#Set a Default Icon otherwise the balloon will not show
			$NotifyIcon.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon([System.Windows.Forms.Application]::ExecutablePath)
		}
		
		$NotifyIcon.ShowBalloonTip($Timeout, $BalloonTipTitle, $BalloonTipText, $BalloonTipIcon)
	}
	
	
	
	function Load-ListBox 
	{
	<#
		.SYNOPSIS
			This functions helps you load items into a ListBox or CheckedListBox.
	
		.DESCRIPTION
			Use this function to dynamically load items into the ListBox control.
	
		.PARAMETER  ListBox
			The ListBox control you want to add items to.
	
		.PARAMETER  Items
			The object or objects you wish to load into the ListBox's Items collection.
	
		.PARAMETER  DisplayMember
			Indicates the property to display for the items in this control.
		
		.PARAMETER  Append
			Adds the item(s) to the ListBox without clearing the Items collection.
		
		.EXAMPLE
			Load-ListBox $ListBox1 "Red", "White", "Blue"
		
		.EXAMPLE
			Load-ListBox $listBox1 "Red" -Append
			Load-ListBox $listBox1 "White" -Append
			Load-ListBox $listBox1 "Blue" -Append
		
		.EXAMPLE
			Load-ListBox $listBox1 (Get-Process) "ProcessName"
	#>
		Param (
			[ValidateNotNull()]
			[Parameter(Mandatory=$true)]
			[System.Windows.Forms.ListBox]$ListBox,
			[ValidateNotNull()]
			[Parameter(Mandatory=$true)]
			$Items,
		    [Parameter(Mandatory=$false)]
			[string]$DisplayMember,
			[switch]$Append
		)
		
		if(-not $Append)
		{
			$listBox.Items.Clear()	
		}
		
		if($Items -is [System.Windows.Forms.ListBox+ObjectCollection])
		{
			$listBox.Items.AddRange($Items)
		}
		elseif ($Items -is [Array])
		{
			$listBox.BeginUpdate()
			foreach($obj in $Items)
			{
				$listBox.Items.Add($obj)
			}
			$listBox.EndUpdate()
		}
		else
		{
			$listBox.Items.Add($Items)	
		}
	
		$listBox.DisplayMember = $DisplayMember	
	}
	#endregion
	
	$buttonLogin_Click= {
		#TODO: Place custom script here
		$global:user = $usernametextbox.Text
		$pass = $Pwdtextbox.Text
		#| ConvertTo-SecureString -AsPlainText -Force#
		$CurrentDomain = "LDAP://PFG.com".distinguishedName
		$dom = New-Object System.DirectoryServices.DirectoryEntry($CurrentDomain, $user, $pass)
		if ($dom.name -eq $null)
		{
			$Loginstate.Text = "Failed";
			$Loginstate.BackColor = "red";
		
		}
		
		else
		{
			$Loginstate.Text = "Success";
			$Loginstate.BackColor = 'Green';
			$panel2.Visible = $true
			$buttonLogin.Enabled = $false
	
			$global:Pwd = $Pass | ConvertTo-SecureString -AsPlainText -Force
			$global:cre = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList ($user, $Pwd)
			$global:credentials	 = Get-Credential $cre
		}
	}
	
	
	
	$buttonSearch_Click={
		#TODO: Place custom script here
	
		if ($radiobuttonHO.Checked) { $global:domain = "HO"; $global:DCServer = "hosbrdadc02" ; $nameconven = "grg_app_hrpro_*"; $employeenamingconv = "grg_app_hrpro_employee*"; $global:agentnamingconv = "grg_app_hrpro_agent*" }
		elseif ($RadiobuttonUK.Checked) { $global:domain = "PFG"; $global:DCServer = "pfgdc02"; $nameconven = "ggHRPro_Employee*"; $employeenamingconv = "ggHRPro_Employee*" }
		$OutputBox.Text += " Please Wait Searching.... `r`n" + "Server : " + $DCServer + "`r`n"
		$ADuser = Get-ADUser $searchtext.Text -server $DCServer -Credential $credentials
		
		$RadioButtonHO.Enabled = $false
		$radiobuttonUK.Enabled = $false
		# Which HR Pro groups are this user is member of 
		$global:Adusergroups = Get-ADPrincipalGroupMembership -Identity $searchtext.text -Server "pfgdc02" -Credential $credentials	 | ?{ $_.name -like $nameconven } | foreach{ $_.name }
		
		
		# Clean the checklist boxes if they have anything already incase 
	
		$EmployeeList.Items.Clear()
		$AgentList.Items.Clear()
		
		
		$listallEmployeegroups = get-adgroup -Filter { name -like $employeenamingconv } -Server $DCserver -Credential $credentials	 | foreach { $_.name }
		$listallAgentGroups = get-adgroup -Filter { name -like $agentnamingconv } -Server $DCServer -Credential $credentials | foreach { $_.name }
		
		foreach ($listallEmployeegroup in $listallEmployeegroups) { $EmployeeList.Items.Add($listallEmployeegroup, $false) }
		foreach ($listallAgentGroup in $listallAgentGRoups) { $AgentList.Items.Add($listallAgentGroup, $false) }
		
		if (-not $ADuser) { $OutputBox.Text += " User Does not Exist on PFG Domain"; $formOpenHRADMembershipTo.Refresh(); [System.Windows.Forms.MessageBox]::Show("Invalid User $ADuser"); $ADuser = ""; $Adusergroups = "" }
		
		else
		{
			
			$panel3.Visible = $true
			$OutputBox.Text += $searchtext.Text + " : User Found `r`n"
			
			
			$employeegroups = $listallEmployeegroups | ?{ $Adusergroups -contains $_ }
			$agentgroups = $listallAgentGroups | ?{ $Adusergroups -contains $_ }
			
			foreach ($employeegroup in $employeegroups) { $EmployeeList.Items.Remove($employeegroup) }
			foreach ($employeegroup in $employeegroups) { $EmployeeList.Items.Add($employeegroup, $true) }
			foreach ($agentgroup in $agentgroups) { $AgentList.Items.Remove($agentgroup) }
			foreach ($agentgroup in $agentgroups) { $AgentList.Items.Add($agentgroup, $true) }
		}
	}
	
	$ChangeButton_Click={
		#TODO: Place custom script here
		
		try
		{
			$OutputBox.Text += " Wait"
		}
		catch { $OutputBox.Text += " System Crashed restart this application" }
		$OutputBox.text += " Please wait Adding users in progress... "
		
		try
		{
			$panel2.Visible = $true
			Write-Host $Adusergroups
			foreach ($Adusergroup in $Adusergroups)
			{
				Write-Host $Adusergroup
				remove-adgroupmember -Identity $Adusergroup -Member $searchtext.Text -Server $DCServer -Confirm:$false -Credential $credentials
				remove-adgroupmember -Identity $Adusergroup -Member $searchtext.Text -Server "pfgdc02" -Confirm:$false -Credential $credentials
			}
			$OutputBox.Text += " Removing old groups success"
		}
		catch
		{
			$OutputBox.Text += "`r`n  `r`n "
		}
		
		
		$EmployeeList.Refresh()
		$AgentList.Refresh()
		$newgroups = $EmployeeList.CheckedItems
		$newgroups += $AgentList.CheckedItems
		
		if (($newgroups).count -gt 0)
		{
			$OutputBox.Text += "`r`n New group are `r`n $newgroups "
			
			try
			{
				foreach ($newgroup in $newgroups)
				{
					
					Add-ADGroupMember $newgroup -Members $searchtext.Text -Server $DCServer -Confirm:$false -Credential $credentials
					Add-ADGroupMember $newgroup -Members $searchtext.Text -Server "pfgdc02" -Confirm:$false -Credential $credentials
	
					
				}
				
			}
			catch
			{
				$OutputBox.Text += " `r`n `r`n "
			}
		}
		else { $OutputBox.Text += " `r`n User removed from all the groups`r`n " }
		
		
	}
	
	$buttonExit_Click={
		#TODO: Place custom script here
		$formOpenHRADMembershipTo.Close()
		
	}
	
	$labelOpenHRADSecurityMana_Click={
		#TODO: Place custom script here
		
	}
	
	$picturebox1_Click={
		#TODO: Place custom script here
		
	}
	
	$panel1_Paint=[System.Windows.Forms.PaintEventHandler]{
	#Event Argument: $_ = [System.Windows.Forms.PaintEventArgs]
		#TODO: Place custom script here
		
	}
	
	# --End User Generated Script--
	#----------------------------------------------
	#region Generated Events
	#----------------------------------------------
	
	$Form_StateCorrection_Load=
	{
		#Correct the initial state of the form to prevent the .Net maximized form issue
		$formOpenHRADMembershipTo.WindowState = $InitialFormWindowState
	}
	
	$Form_Cleanup_FormClosed=
	{
		#Remove all event handlers from the controls
		try
		{
			$buttonExit.remove_Click($buttonExit_Click)
			$ChangeButton.remove_Click($ChangeButton_Click)
			$buttonLogin.remove_Click($buttonLogin_Click)
			$panel1.remove_Paint($panel1_Paint)
			$buttonSearch.remove_Click($buttonSearch_Click)
			$formOpenHRADMembershipTo.remove_Load($formOpenHRADMembershipTo_Load)
			$formOpenHRADMembershipTo.remove_Load($Form_StateCorrection_Load)
			$formOpenHRADMembershipTo.remove_FormClosed($Form_Cleanup_FormClosed)
		}
		catch [Exception]
		{ }
	}
	#endregion Generated Events

	#----------------------------------------------
	#region Generated Form Code
	#----------------------------------------------
	$formOpenHRADMembershipTo.SuspendLayout()
	$panel3.SuspendLayout()
	$tabcontrol.SuspendLayout()
	$EmployeeTab.SuspendLayout()
	$AgentTab.SuspendLayout()
	$panel1.SuspendLayout()
	$panel2.SuspendLayout()
	$chart1.BeginInit()
	#
	# formOpenHRADMembershipTo
	#
	$formOpenHRADMembershipTo.Controls.Add($labelAuditTrail)
	$formOpenHRADMembershipTo.Controls.Add($labelOpenHRADSecurityMana)
	$formOpenHRADMembershipTo.Controls.Add($picturebox1)
	$formOpenHRADMembershipTo.Controls.Add($buttonExit)
	$formOpenHRADMembershipTo.Controls.Add($ChangeButton)
	$formOpenHRADMembershipTo.Controls.Add($Outputbox)
	$formOpenHRADMembershipTo.Controls.Add($panel3)
	$formOpenHRADMembershipTo.Controls.Add($Loginstate)
	$formOpenHRADMembershipTo.Controls.Add($panel1)
	$formOpenHRADMembershipTo.Controls.Add($panel2)
	$formOpenHRADMembershipTo.AutoScaleDimensions = '8, 17'
	$formOpenHRADMembershipTo.AutoScaleMode = 'Font'
	$formOpenHRADMembershipTo.BackColor = 'ButtonFace'
	$formOpenHRADMembershipTo.ClientSize = '1132, 673'
	$formOpenHRADMembershipTo.Name = 'formOpenHRADMembershipTo'
	$formOpenHRADMembershipTo.Text = 'Open HR AD membership tool'
	$formOpenHRADMembershipTo.add_Load($formOpenHRADMembershipTo_Load)
	#
	# labelAuditTrail
	#
	$labelAuditTrail.AutoSize = $True
	$labelAuditTrail.Font = 'Microsoft Sans Serif, 7.8pt, style=Bold'
	$labelAuditTrail.Location = '893, 98'
	$labelAuditTrail.Margin = '4, 0, 4, 0'
	$labelAuditTrail.Name = 'labelAuditTrail'
	$labelAuditTrail.Size = '82, 16'
	$labelAuditTrail.TabIndex = 13
	$labelAuditTrail.Text = 'Audit Trail '
	#
	# labelOpenHRADSecurityMana
	#
	$labelOpenHRADSecurityMana.AutoSize = $True
	$labelOpenHRADSecurityMana.Font = 'Microsoft Sans Serif, 7.8pt, style=Bold'
	$labelOpenHRADSecurityMana.Location = '375, 8'
	$labelOpenHRADSecurityMana.Margin = '4, 0, 4, 0'
	$labelOpenHRADSecurityMana.Name = 'labelOpenHRADSecurityMana'
	$labelOpenHRADSecurityMana.Size = '565, 16'
	$labelOpenHRADSecurityMana.TabIndex = 12
	$labelOpenHRADSecurityMana.Text = 'OpenHR AD security management for Employee Self Service and Agent Services'
	#
	# picturebox1
	#
	#region Binary Data
	$picturebox1.Image = [System.Convert]::FromBase64String('
iVBORw0KGgoAAAANSUhEUgAAAIwAAAAsCAIAAAA4vseHAAAAIGNIUk0AAHomAACAhAAA+gAAAIDo
AAB1MAAA6mAAADqYAAAXcJy6UTwAAAAJcEhZcwAALiIAAC4iAari3ZIAAAAGYktHRAD/AP8A/6C9
p5MAAAAHdElNRQfgBBkKGy8NcXziAAALN3pUWHRSYXcgcHJvZmlsZSB0eXBlIGV4aWYAAHjalVTZ
rSC5bv2vKF4I3CmGwxVwBg7fH7fbMz02bDwRqBJXkYeUvv3P/7jvX//6178YwD9RfxZmAAASEpQA
8OBnOQASIDAA4C8ZAuzdYgKC/iX/jH7p60+F5c+f3j8CEcDuJSMgEADur0D+KxDTL4X88PHLz+I5
yF+B8pe+fwWg/tF8vw1+C37zgiZ2RqYECvbsXOyc7dk5EAgrMxPIGBpbfLa/DQCYGBg4OBnYOJk4
CBgZOVl/SRzgp9SEv5f83d1lYwAl/L0Ev18b/lPOAAp/XwYADPj9AaQBjB39syP4q+x/NoTkZ0fv
n4EI4LkpINDfs/hv/OhP+RvI34l9/xvQ/+Tv5t0tACBIikmIAfx0GUAegLzvx3AHAPqvTukJywAA
3e0CwP6lAzD5PbGAd1MATz4AaHjw4EHAg4aAgEaEgoRCRIWDhoZDxYeMjIqMjA8R+i/6/mT/LUIY
KCgYWJgPARYWAQUWFhbl9w4W5e/HIP556D8y+ndyuGsAQIQHwASQAAxIBAD0IQICIwLezcDP8OVd
CyDfr94p4N/oz/UzPvSBgIKBw4OAhAL8f10RAAj4T88P6mdoQQCBgUCAQMHB4IECQzP/uCICgxAi
MYIKKhoiEzk+ZPrAUAITC4WISVCVGo2YWZweDQqDkwYpHyweGjuzoiUVPSYTCVb5TESbkl3Y0IdU
l0yPip80D7suH4uRh6Q8LQltGVk5SS1tHV09/dTM3J6FpZW1ja2dsYurm7s/D08vbx9fP0f8ded+
7qP8xuoDBwcDZf0LCUJGJJAfHByJkEGZHgai/IahUWnwgJnE6Ft0ehQkrIxq7MxySAr2GwVwMtam
oR80ktFNRFXZXEyXjoq/P5H4v3H432EgZxf//onE3SQANPyt6YgAfACnKkEaHnqanGCkZ8Yra9+4
6ihOGeMwQdu+S77KlZBNkowFV9+IkYf8OFhX0DbXChvqwaF/zBul6l2XPQMORXhvwiN02FUEvHCY
IIDabu12OUg5X1Bvw2XzfOgZJtjW2JV79Vjm6ZuIyaGxisl3s16Ix5fpshulr5iLqNqt0u3bcwBp
58I4mbsJCZmUMFn0sbqsivFyLHTO8hnDZwy7ho43Y575jdk6jUlISoCjDdvIOjKjafYdU/v4nbdw
v00fdsw5cXLalzQP/BsuamMc8H1VVtM4u08e1ITI2E5KMBC8wHzcKBsUEiQPI+KePlT46tiJqi1f
PQYNq8dYFXOiVbGaQcEpEb1WmLpHmGMvnN8+AJxOtI/MjNaWi6lgx0yMJ8mqrAh7XHDSraKuE4KC
SYLkV1JBkn438J2qtp+8tKjbytMwHS0be/YI8wCb/ITzKtygXjY3X7mP9Va9pKvP8dW8Idp2ty5M
TQuHeYd3ADJ1sQ+VKmfJyGUvZ4aoN3Js0HXPvleb+cDe5HpZ0M6bOxnlvLkDOMRNXyNeUJa5A9Dj
zKLNKStQGvp+p25LVrCaNXSb5bIbE+ZcPhMeaX76OnzPX2BpayX79NoV+3cHwFF8YoWWLVd247yl
r7a03lq3W+sIv6K2AIbpcaa2O4CsIalveLobN+qdrzO93Dqh9Jq1MtZcGnun2DM9eP2010dlA3qz
Nn0Mvy0YDA0OOofUMphuY31SPK/dy6fMLjfuAMQ67wCGNIyG3QWq8L7kU2q1tVXzqXCpKb3J7LmS
bS/MyRIs94rZE7x8FSErLpAZhjcfLXNsl8a0rXNudvtRvDuAy5KQXZ930PO6ZFAvQ620ztidTWzO
Pk525smdfF0Rl4fBoe/eDfeyninohY1Vj5wzVFTpbPs2zXTrMH307Lmo77WU3DM1Ld/tqKYl3gJs
xNNj5p0ast6S9pMx1nolQ7T+sa6u0Z6LJ8zUJV8J80no5avifQCvudZrbS3uJqJG2Zddovly/Asc
o92EtlU+eArXRFo0xjpn7/SsL+vE0n1/ZkfkWuzFVrpoMX4GLqNrlVq8pS7Rcll+6ladOHzkPBVt
c0plJp4yebZiVMTOPqOf2rrf04lLuXukadN1OTxa2aYu1ripagD7SpbL6RiMy8ZXTHT0vnzrL22I
qr39rGpen98B7MvZ3n2ha665EaMxVvFuw+hg8gEI384HbUPuXBvsw5P5TukyJ9ROpTzLxTbdXKKr
y9iqZ0qLLndQ35TMFxt6B9Azp8UTm+x3kp7vll+w2UOCLU3HQ79Z4idv7wDsxKHSfT6nLfW5QSen
V1pv3ExniDNGtcD6SuH2uasal2uOTVVNzyVeL8F9mlsx4uxJ66dUoOgGuDlqdDJpm1SlsaFyVzwT
NKfxdu4ALMr9voo7gO47gMdaZTcyG3KX9e4AMk901zQ0zOQmtYF30Cp2CyvkLj8Y5xwftdE7AJTE
qFO/JL7NND55HDttzRvnauOrUq6VUXzS7Xsfl5brBdZN3EYgUrvBw7GyG7zIsUDKuXS3nBvhLTjd
3i3Wk+nJ79JOdt+uG3OkPZu+2rZy19u8fIv7Ri9en4ShS162xzw/dU9w8f3inA9mAt/5il6oLkd3
YWjRlJaqi1GR++U7qxotart94ep+o2r7qdncqCe5ann6+KgmrBU9G7Vxhze1ObrFevu01/yeGT3m
TVIWl283SgzXdV6NcAp4OXo+xuxpLas3Yao+sGBZGed+7HcAGUjID1C/dBkqO7kN3/MMbaaqg707
ANGWqi33MbUTdJy16krPUH6h61ovv00tH7TeKZ0X/uzSzS/N1PL4yLd4eKTy+Wh3bbqu8vbG2972
3vuKGd/mUl/xhES7cQ0VvrO9A0grOarNNxU1jPE0bpSJKdfW1KPv6yjMXqtJ3j4ZaqufJ2VyLqHv
AKAuRT1nH8vU+MxYnNULX4iN/bb9PQvD4h2wPuWN3esWfosDsDV8rXLQlcFn9eKW+rDyMW/uksmn
EY+6oSyJsUBUxiLlFfXsXim4Z/jerRa6QcFtjo9WXYKKo5/FpxPxVEuKkTHb1AaVpd7UblHZZfjU
7qXfPcxpxRWCfoEjF7Tv5fse3AHcDZ6qBj4cgMXT6dm8A7B3CmbvnbiJ9SXeInuV37HfvrHKT4JC
ihw9EdsvG8PHanyWaQv1EovYGlKranTW/Q5Afr5WGiTxSerDmFPFd73uShsabi7VXdCTmw987Eh2
nbMTp3yjavoOwD297juJjcu6FK0NkvTIus08lU249LM6fW6qKtz6JrOSKmuaa8/C/eYT2lCSIGXl
NPWNZZ5aDgzaO877eUXPV+MiBp1t+m1OoExSFbN/GCFLre8MrJqpc8a0J9tLp7LN0618pNCGNcfe
s/eQ5LpjWjkJ4sMieODu4eWb60pWsZdP0aCD7Sa3vF7VCGyHrxpPlF3mJo+3J/U3r31GNTbuGK/n
Up7wZp2mLcJUUNspnhVOCE25Y7aB+mNTsp1H307YKafv4PW7jewbR9cMcq+gA60Gbl1lvs1z1c62
smhLxkJ6lV+a2rSiIVF6idlt4es94cGkca3QV5v6pt0nNpjmpE4j96ljDVZ+T8nxiOokpwqd7TpP
pKbHeMLLJtNHTuaKKcvmKmJ74nqHN33Dv/E8H5K3wkUiwN1aA5WlZzflrCUrk1tUrvOS2sE0pMSk
fDsqRr9LL3xXhUx8USfFtC03fOkXoU6V5GPQvuFe7JetoRO+lzmlY+Gfz6Pb2G5Oq5MbqRid3cRR
nU3PCLw+njjLW+dCCTqHM3gLuLTmn0hDR/OVRml2UlQOXHtLRut2RuLrnCvtNdXy8dJ3FadjfXLX
5N9x2XTJkARLFFs9SJSUIAmQuruhU5XwzgyS9M38H9z3fyn/He77/03vJr7/ArMkbG7lW+joAAAA
JXRFWHRkYXRlOmNyZWF0ZQAyMDE2LTA0LTI1VDEwOjI3OjQ3LTA0OjAwcOxCjAAAACV0RVh0ZGF0
ZTptb2RpZnkAMjAxNi0wNC0yNVQxMDoyNzo0Ny0wNDowMAGx+jAAAAAVdEVYdGV4aWY6Q29sb3JT
cGFjZQA2NTUzNTN7AG4AAAAhdEVYdGV4aWY6RGF0ZVRpbWUAMjAwOTowNjoyOSAxMTo1NjoyN7vU
XXAAAAAZdEVYdGV4aWY6RXhpZkltYWdlTGVuZ3RoADEzMji9bdYqAAAAGHRFWHRleGlmOkV4aWZJ
bWFnZVdpZHRoADQyMjPvh3tqAAAAE3RFWHRleGlmOkV4aWZPZmZzZXQAMTY0zHsrFAAAACt0RVh0
ZXhpZjpTb2Z0d2FyZQBBZG9iZSBQaG90b3Nob3AgQ1MzIE1hY2ludG9zaKSb0W8AAAAcdEVYdGV4
aWY6dGh1bWJuYWlsOkNvbXByZXNzaW9uADb5ZXBXAAAAKHRFWHRleGlmOnRodW1ibmFpbDpKUEVH
SW50ZXJjaGFuZ2VGb3JtYXQAMzAwqyoLcQAAAC90RVh0ZXhpZjp0aHVtYm5haWw6SlBFR0ludGVy
Y2hhbmdlRm9ybWF0TGVuZ3RoADI3MDEomsxmAAAAH3RFWHRleGlmOnRodW1ibmFpbDpSZXNvbHV0
aW9uVW5pdAAyJUBe0wAAAB90RVh0ZXhpZjp0aHVtYm5haWw6WFJlc29sdXRpb24ANzIvMdqHGCwA
AAAfdEVYdGV4aWY6dGh1bWJuYWlsOllSZXNvbHV0aW9uADcyLzF074m9AAARb0lEQVR4Xu1aB1RV
V7q+hGTm5bnmzeRNslbWrJelKRMnYzIzaSaamGfUmYyZ2GKld7j0ckFABBEVpYP0IlWloxRBpHdQ
QJrSld57b4H59tnXQ7k0Y5wZVvjWda+9//Of/5y7v/23i5yZdfzHY52kNYB1ktYA1klaA1gnaQ1g
naQ1gHWS1gDWSVoDWDMkTU9P9/f38Rc/M6wZkqampqqrKshsepoR/IywJEk4uT/8MPWDACDnazzB
UpoMpgT1KehVZqQg86WUgcnJyZLi+5gso/M8gMct9Tzyuv+Sd/kxngROnuXtQAZ/9jSYmBjPyc7A
RPDRoHdyavaDt+NfeGY8VxJWT/EiJNF7a2uq01OTc7IycrMz6ScvJ7OstLinp5tVo5rtba2MZjo2
kVVm9LMy01Mb6uuoMjsCcIvqqsqUpDsRoYGBV31Dg64l3I4tf1g2PDxEFQQxNjaWlHAbE9bIMsAh
4s+eGV39w1NT5FQtsAhhU3vPyNgEf/08sQhJ9KR7uTmJHtmvKCMmcfyg2NEDYscOSJw4pCgjytPg
enu49PX2QGdqchJjYnysyOHvlGTFJUW+p5pkPHpA8sShA3t3+V5xJzan+HEPY3JivJmJIfShKXJk
n+jR/aJH9mEufvygg40F1cG4AKOjIzGREZjMvUrJ8I/L49mG6Dnf1HWMsAq4U1TdBCH7ODrONYkF
EwtmRWQxVwPHiCEmo7jmN9vV9um7z1WYwLXp6fDUope3yBi4RkFClaGwwCxAl4KXwHFrV9/o+ASR
zr9FEEuSFODrpSQrpqOu5Obs4Oft4ePldtnWAkuunLi85AkTQ92+3l6qmZqcoCQjpqWqYG990e+K
O1jBiI+/j6eHy+X8u7mMzSmMAwP9dlbm8lInZMWP6WhwPV0d42OjM9NT4CJB1/yMTmrH3SLfedF4
CCeDw/EXT0Aj21YFa85bYpyPlDh/lue8Iy78KdczKgty+uXnRj9IEA75CxIn522Q4FbFZJdx/iAF
+0RvmsRV/oWZGd/YPM7GE0pWQZiDpPlmiV3+Yr5ZXKKM3kwv3vC+rLFnDOYrcbQ0SdhieSkRbD0b
34DWlmZL87PqXFk5yeNQoEJELUVpUTBKE7sgmG84PTY2eun8GQUpEWV5SQ9Xx/b2Nv7lJ0D9tig9
FIODA+wTWVAC/s5zefF9WZ9budVNHac9Yjh/Ufj1Nyd7B4dx5PuGRqAwMjZOQxZF3+BIXXNn78Aw
XeLdBkfGhkfH6ZICN9Jb0oqqoYsJS0NdS1dbd//V+HtCb4up2oZCggdhROiD2Z7+eRG7b5A8BR6D
S/RlqLJLRDpno4j8petDw6ND8x8tiJVJam5ugoTdwe6uTm01RTUlmZM6avAMSFISCUlcWXE4DXSQ
bzCywBZghFpwYABcEAzBL7EEqAILKhQELGBEkwRqqYQFJelv2s6czZJxuQ8wh/LvDhlzPlSsbuww
dIt6bTdvj6bTr/5f62NZSyj3D43InA/4rx2aIPKXOzTEz/j0DAz3Do68cch402GT9p4BeqZ9Y3Nf
/UgxJqusrrV7426e9IUARjyTkF/5ieRFzsdKnE+VX/vuFOdP8kqWxJPw0ItXE/53Nw+u/NJ2dVnz
qwNDo5BHZZa+ulMbjvgyc+m3e3gmV2IhdwpPE/5Q4aWd2sJfaQp/of7bbw06egepHYyCWJkkeA+W
9H56yd76EjIK/KnucS2WyDGMJ4kX3MtjdVjQG9vaWjWU5VQUpExPn5yYIIF4GVYWgFro7e1xtLOa
nh+TZkl6VzKlsArz+rbuV/6mh03EjktfuAr56weMPpK8+IWyLcx8p+/O2STyhbLdKY/oL1XsOW+K
fq1BiN+mZIt5wO27xOjMzHYVO84W2aaO3nvl9Qik27m2EN59WPfi56rY6yPG3sh/WyTMOX+UVrAI
xCWn8HSofSB5ERzs0XKGKdGzfpBficlBtPzVHl2udbCGfdiGXTwcptTCqsyS2k/FLrzwKXezyHkR
Ex9Fy0C4MvSX4OjpScLEzdkeBQWcqaaa7MvyJNFshJwPHdyVkZZChFNEuErQR8ODrS+dEzBOLu3R
cuK8Lytu5m/gFvUH0fPYr8+UbCCXOOcvtFkyvaiG0Z3JffAYah9ImFODGP8idQm7VlrbHJiQL/Sm
6AFDEk4ft3QJb1X+XNkO84ziWqH3Zb/WuIz5AQMPJDzL64mYA8FJheBbjQl3/3fIGM5a1dAOm119
g+8eN3txmxr2PSKtWOgtUa5VML3lrHfsC2+K6jrdwDwwMR8pjc5XxKpIwrMhZEA219zMmCsngUtt
rS1YziUJmgiMGCnITjA7YmtpDoZ0NZXhEFhS4QIwugT89RNQSUdHO55L60kWlKTdmo6kaviYy/lA
7qUv1ffxXLDRkOM4k5N7v5pacAxLAxNcJtXTk6tuFyq0UQTBB8tffKH+31/rjE9MeuP4bxRBzsBN
uJfzR5m/ajvDwuv7jYS2qSIAotxA8veLywNJOo43kOGEvtQQ2qHB2abG+YTL+VyFjO+Ilz1qQcCE
DhIP9PEhDrdJBMTgpHtEZnLeElW1CYF8dHzelxLECiRpqsijDaJyisL8u4ha+Jw3NUL6geRJ4SBe
WHCP6iwASgYjfR0FaVGLC6Z80dOAbjEOhOlpfbS0VEhBScImct6Tdo/MrKhra+4gSZ5CwswfJNEw
CD2r64kgSdMhDOkVZQJG7JfQJpFzvnFQ+IbnwnlbLCar9OAprxc+4TYydlCCI6Z9o+OMPXllr77Q
Ds2G9h5sK/Iz8hbdccRVzlaVV741ULYOlr8UCEoULQLVrIOR6sJS7iP0QULeBmkiJJXc4ky8xys6
G5dUbUNg6hlJOoEa4VFtDapteEBjQ31sTCSqcGQXGfGj6HOpPkgCAagIsjLTwGhHe1tnR3tnJ45+
2+goyZ/d3V3wIdR1qOaxpPYFgTKku6trZJhfdLGgJDU3NZ7W1wHfrASYzUmbJRPzmV/2GCGtoBAA
qSdROdmy30v8Q5/0bRSIbzjy/kwq8r6VA6Y/U7TZsFN7l5YTVUDygCft0iR5689Sl4S3yMA56CX0
SdhxTYdwfJ0Nu3mv7OaNz/dy4PqdfBAP5ujSIZQhiQlxntFZCH06jqTzWxHLkSQneQKbW1pSZGzI
o2lfWvQwKjRU25E3SCyemuJ7koI0Kayzs9KRNtDwwv8QDMEKbZJQNYBa+KW3pytrfwEmJybgmgiJ
/OZ3jg6lBEfEgKcxMkIoXEDSNzouwu9JR2eVsfTQ6hk5CXLqSYgwKORe/dbghY+VEKngEAHxd1/c
qvzrv+rCFaCAEYU750sNFH5QgAQAScIfyO1UJzmJbPHbYm8cNL52515W6SOp8wHCm6VodYduCQlm
q7xVdFZp/N1yUSMvJDC8GTSF3xGfS5LwW2LUk4gjvi2GsiWloMo2KHlolCkcGDVBrBDuUMKh9oXT
oEw4dVILWQFy+ms0dgrpBxMa7uBMD8tKGxvqwJCeloqelip4elRLTjFyPsiGX6K3Ze3PgtnxifFx
NMjSYkcEdSglDfV1KPqHGT9jSUJ6wLhTzYHzxvFb2eSMU3oQkTCeOOMDeRrjSeMMebE5D/7nK034
E8lhv5d4ebsaHIK9evT0Fez1hj28zt5B+giQgaD0lao95rCpbBPM+VABzoeajbNVGW4qe5H014hs
+1E3bpHhvCvBeU8KCrS6Qy/Fef2wjDm/Byfh7rVDegxJje29mw6fIXZgbZtqWw9pZtjvtQCrKhyw
HBwYQCBirdAJ1aQk0T4JS2iCVwyYULXx8TH4IhwLjTCWAiA6SDamRidlJY55upFQI0hSU2ODoS48
ifSDC16jqLopJq2on2lN4DGsvLKhPTajhO1S6aW69h6nkBQ9h3C764nVTZ1E/gPzmw1TvrsGJiXl
V7LK6E9jM0tKambr2+KaJt+YHP+4vNLalricshrGAkVu2aMrUVlX4/JKasjvUgD65VtpRawOnPVW
6n04MV2iNwqIzfWLyamoJ309Y35xrIokdlMAXGV3kBZ7bOFAqzt6iQWVoMWBjo4Gt6e7G5L5amQO
ks4Y6cmKgySSANhHAFS5pbkJTI+N0X5i4VNWCRoe50JQsgwoc4KA+Glf6an0V+tJEAraFSQJy3kl
+BwdxEMlGTH66xwtC5+AqK1IUntb27kzp9AIU+ECIMqhTEJEausewItisuBDXx8TJK2xiUlMEOJQ
cOMKamh8cH18YmoU/6aIZC55Y+OTkGICZdxCb8SHuZv/YyAmk1NEDmWM9J0xwBpLLYRY0kt0CQPE
xkoHZbUksabnYlGS5u4vQG8cGhpE2kfpAWeCT0BCf2eiDRgGlG3Lk9TV2WlhfpZmQRb06xm5R8uc
9VO3CUnKr6D19IpgNw5AWkKG5y8YiJr6NrSRoIRQaeAaqWYZpGUfSnuvfwueO0kAldzNzUbtoKoo
jUq6qrKcXpoL09MnQZKX++I5qbenx8HGYsFr0MJhr65rYRUhHgk88V4FcoB/bK5VwJ3M4locdo+o
LGvfuMLKxu7+YchtrydGZpRAuaqxw8L3NqqsrJLa8rq2/Ip6S584FOLws4OGnrXNJJHIXbym7xoJ
yRBcbHIKhaJbaGppbXNyQaWFZ0xO2WOQHZVJrBVUNqB7hYJDULJtYBLeBMJFN+1HYEmSyJ8qZMif
KlqZnxWWIIlopiYncOXEVeQl0eeywgWgwvjYaBToiHso6FGO38vLqa97jEOAyi0zPVVPWxWXXB3J
7zGCJKEYcWcKv7mgoebI6SsqFwLQHuKwHzfxcbmRcfiUZ3ph1TYlGzAB2oLi76IhRfn3lYp9VnHN
DhU7VAf/0HONSS9OL6pBuWV5LbGoqjGjsGqXukNEWhG4qW/rATefKVoj/tFnAXt5ru5hqaiY4WoZ
jAV4IRoAvKCJ1y37kJTDRl7BCfnO4WmHDD1JoHiahLcMliTJy81J7Oh+8NTc3Ijl4iQxwSchPlb8
+EFJke/zcrOJcDGSACovul9wzsQQVIkfO4Bb4ILKchJwWYnjh9CBoUcODyH9uaCRocFBODd/8QTU
k0DStbg81EjYWTQuYMviWgKVP6xrC00uNHaL+v6U1430Yu3LpHmEc3Ctgk663CQmZmacI9LRweB2
q8DEfVpOwUmFChaBMAXn+VzJBpkGOnG5D/zictXtQpFv9V0iQ1PIH2XsglPQIdE/KdkGJ7vdzFSz
DYG/YomugLZfP4kzLUIS8gTGjLRkl8s2Pl5u/X3kP1It40nlD8pw/N2dHeiP4su8FtVHCwyqgq8H
IHyhgTUzMbQ0N0PlHX0zvLLi4VIco40NC+b/vsKCkoSzfJ/5a+zj1m70Ro5haWgYcYqPmXijpUf3
0949sFfXJSixQNzMH3IxMz+HkFT4Vl1LV0tXv4lXjKl3LNyrvK5VzS7UMypL7KxfRX07DMpdusZz
jOjpHzbzidVyCFO0DGxs74F9zJGuREx9XSLS92g6dfUNaTmEwyZaosLKhpyyR3u0nNjy4dmxCEnP
FQs4wNdA1cBfLAtUFrExkcx09pvT/G8dmFTd2AFLnX1DbjczEMpCkgshtwtOzq9oQOY3cLpxwe82
sg7yE+SXQ1PrWrtvpBVzz/tfDLgTcDsvASExsUDPPkzDJvheeZ3rjQxUidCEM53zidOyDVG1CMwu
fXQlJqe5s290fPKUe5SG+VVz/3i8ALxQ0yaYZx+WWVILdtWtglSsgmhrNbc8eRYsSRKzewT89dJg
NTHhi1aCoD4jIGGcvxbA+Ph4WkoSJqt/ynMFilP+bA728lzYXvUnxL/ak3400FoVMIWJIElz6Wbm
0/QIY44JlYB/ImfCIzMlRQe5MKtAx1k1AGroYzBCQj6MWfyjYRbKdCQ3MvdnFNcMDo9RZXL/T4Q1
QxI6pIpy8gfynyHWDEk4p93d/7Z2cpX4aR2IxZoh6eeMdZLWANZJWgNYJ2kNYJ2kNYB1ktYA1kn6
j8fMzD8Byz4GHPcUxEgAAAAASUVORK5CYII=')
	#endregion
	$picturebox1.Location = '915, 43'
	$picturebox1.Margin = '4, 4, 4, 4'
	$picturebox1.Name = 'picturebox1'
	$picturebox1.Size = '162, 42'
	$picturebox1.TabIndex = 11
	$picturebox1.TabStop = $False
	#
	# buttonExit
	#
	$buttonExit.Location = '1022, 630'
	$buttonExit.Margin = '4, 4, 4, 4'
	$buttonExit.Name = 'buttonExit'
	$buttonExit.Size = '100, 30'
	$buttonExit.TabIndex = 10
	$buttonExit.Text = 'Exit'
	$buttonExit.UseVisualStyleBackColor = $True
	$buttonExit.add_Click($buttonExit_Click)
	#
	# ChangeButton
	#
	$ChangeButton.Location = '581, 623'
	$ChangeButton.Margin = '4, 4, 4, 4'
	$ChangeButton.Name = 'ChangeButton'
	$ChangeButton.Size = '100, 30'
	$ChangeButton.TabIndex = 9
	$ChangeButton.Text = 'Change'
	$ChangeButton.UseVisualStyleBackColor = $True
	$ChangeButton.add_Click($ChangeButton_Click)
	#
	# Outputbox
	#
	$Outputbox.Location = '781, 118'
	$Outputbox.Margin = '4, 4, 4, 4'
	$Outputbox.Name = 'Outputbox'
	$Outputbox.Size = '341, 501'
	$Outputbox.TabIndex = 8
	$Outputbox.Text = ''
	#
	# panel3
	#
	$panel3.Controls.Add($tabcontrol)
	$panel3.Location = '26, 172'
	$panel3.Margin = '4, 4, 4, 4'
	$panel3.Name = 'panel3'
	$panel3.Size = '722, 488'
	$panel3.TabIndex = 7
	#
	# tabcontrol
	#
	$tabcontrol.Controls.Add($EmployeeTab)
	$tabcontrol.Controls.Add($AgentTab)
	$tabcontrol.Location = '4, 4'
	$tabcontrol.Margin = '4, 4, 4, 4'
	$tabcontrol.Name = 'tabcontrol'
	$tabcontrol.SelectedIndex = 0
	$tabcontrol.Size = '696, 443'
	$tabcontrol.TabIndex = 0
	#
	# EmployeeTab
	#
	$EmployeeTab.Controls.Add($EmployeeList)
	$EmployeeTab.Location = '4, 26'
	$EmployeeTab.Margin = '4, 4, 4, 4'
	$EmployeeTab.Name = 'EmployeeTab'
	$EmployeeTab.Padding = '3, 3, 3, 3'
	$EmployeeTab.Size = '688, 413'
	$EmployeeTab.TabIndex = 0
	$EmployeeTab.Text = 'Employee'
	$EmployeeTab.UseVisualStyleBackColor = $True
	#
	# EmployeeList
	#
	$EmployeeList.FormattingEnabled = $True
	$EmployeeList.Location = '7, 7'
	$EmployeeList.Margin = '4, 4, 4, 4'
	$EmployeeList.Name = 'EmployeeList'
	$EmployeeList.Size = '641, 382'
	$EmployeeList.TabIndex = 0
	#
	# AgentTab
	#
	$AgentTab.Controls.Add($Agentlist)
	$AgentTab.Location = '4, 26'
	$AgentTab.Margin = '4, 4, 4, 4'
	$AgentTab.Name = 'AgentTab'
	$AgentTab.Padding = '3, 3, 3, 3'
	$AgentTab.Size = '688, 413'
	$AgentTab.TabIndex = 1
	$AgentTab.Text = 'tabpage2'
	$AgentTab.UseVisualStyleBackColor = $True
	#
	# Agentlist
	#
	$Agentlist.FormattingEnabled = $True
	$Agentlist.Location = '7, 7'
	$Agentlist.Margin = '4, 4, 4, 4'
	$Agentlist.Name = 'Agentlist'
	$Agentlist.Size = '674, 400'
	$Agentlist.TabIndex = 0
	#
	# Loginstate
	#
	$Loginstate.AutoSize = $True
	$Loginstate.Location = '815, 43'
	$Loginstate.Margin = '4, 0, 4, 0'
	$Loginstate.Name = 'Loginstate'
	$Loginstate.Size = '0, 17'
	$Loginstate.TabIndex = 1
	#
	# panel1
	#
	$panel1.Controls.Add($buttonLogin)
	$panel1.Controls.Add($labelPassword)
	$panel1.Controls.Add($labelUsernameADM)
	$panel1.Controls.Add($Pwdtextbox)
	$panel1.Controls.Add($usernametextbox)
	$panel1.Location = '26, 28'
	$panel1.Margin = '4, 4, 4, 4'
	$panel1.Name = 'panel1'
	$panel1.Size = '722, 68'
	$panel1.TabIndex = 0
	$panel1.add_Paint($panel1_Paint)
	#
	# buttonLogin
	#
	$buttonLogin.Location = '542, 15'
	$buttonLogin.Margin = '4, 4, 4, 4'
	$buttonLogin.Name = 'buttonLogin'
	$buttonLogin.Size = '100, 30'
	$buttonLogin.TabIndex = 4
	$buttonLogin.Text = 'Login'
	$buttonLogin.UseVisualStyleBackColor = $True
	$buttonLogin.add_Click($buttonLogin_Click)
	#
	# labelPassword
	#
	$labelPassword.AutoSize = $True
	$labelPassword.Location = '272, 21'
	$labelPassword.Margin = '4, 0, 4, 0'
	$labelPassword.Name = 'labelPassword'
	$labelPassword.Size = '69, 17'
	$labelPassword.TabIndex = 3
	$labelPassword.Text = 'Password'
	#
	# labelUsernameADM
	#
	$labelUsernameADM.AutoSize = $True
	$labelUsernameADM.Location = '4, 18'
	$labelUsernameADM.Margin = '4, 0, 4, 0'
	$labelUsernameADM.Name = 'labelUsernameADM'
	$labelUsernameADM.Size = '113, 17'
	$labelUsernameADM.TabIndex = 2
	$labelUsernameADM.Text = 'Username(ADM)'
	#
	# Pwdtextbox
	#
	$Pwdtextbox.Location = '360, 18'
	$Pwdtextbox.Margin = '4, 4, 4, 4'
	$Pwdtextbox.Name = 'Pwdtextbox'
	$Pwdtextbox.PasswordChar = '*'
	$Pwdtextbox.Size = '132, 23'
	$Pwdtextbox.TabIndex = 1
	#
	# usernametextbox
	#
	$usernametextbox.Location = '114, 15'
	$usernametextbox.Margin = '4, 4, 4, 4'
	$usernametextbox.Name = 'usernametextbox'
	$usernametextbox.Size = '132, 23'
	$usernametextbox.TabIndex = 0
	#
	# panel2
	#
	$panel2.Controls.Add($searchtext)
	$panel2.Controls.Add($RadioButtonHO)
	$panel2.Controls.Add($buttonSearch)
	$panel2.Controls.Add($labelUser)
	$panel2.Controls.Add($radiobuttonUK)
	$panel2.Location = '26, 104'
	$panel2.Margin = '4, 4, 4, 4'
	$panel2.Name = 'panel2'
	$panel2.Size = '722, 60'
	$panel2.TabIndex = 6
	#
	# searchtext
	#
	$searchtext.Location = '99, 24'
	$searchtext.Margin = '4, 4, 4, 4'
	$searchtext.Name = 'searchtext'
	$searchtext.Size = '132, 23'
	$searchtext.TabIndex = 0
	#
	# RadioButtonHO
	#
	$RadioButtonHO.Location = '257, 20'
	$RadioButtonHO.Margin = '4, 4, 4, 4'
	$RadioButtonHO.Name = 'RadioButtonHO'
	$RadioButtonHO.Size = '98, 31'
	$RadioButtonHO.TabIndex = 2
	$RadioButtonHO.TabStop = $True
	$RadioButtonHO.Text = 'HO/PFG'
	$RadioButtonHO.UseVisualStyleBackColor = $True
	#
	# buttonSearch
	#
	$buttonSearch.Location = '531, 14'
	$buttonSearch.Margin = '4, 4, 4, 4'
	$buttonSearch.Name = 'buttonSearch'
	$buttonSearch.Size = '100, 30'
	$buttonSearch.TabIndex = 5
	$buttonSearch.Text = 'Search'
	$buttonSearch.UseVisualStyleBackColor = $True
	$buttonSearch.add_Click($buttonSearch_Click)
	#
	# labelUser
	#
	$labelUser.AutoSize = $True
	$labelUser.Location = '39, 27'
	$labelUser.Margin = '4, 0, 4, 0'
	$labelUser.Name = 'labelUser'
	$labelUser.Size = '38, 17'
	$labelUser.TabIndex = 4
	$labelUser.Text = 'User'
	#
	# radiobuttonUK
	#
	$radiobuttonUK.Location = '384, 20'
	$radiobuttonUK.Margin = '4, 4, 4, 4'
	$radiobuttonUK.Name = 'radiobuttonUK'
	$radiobuttonUK.Size = '139, 31'
	$radiobuttonUK.TabIndex = 3
	$radiobuttonUK.TabStop = $True
	$radiobuttonUK.Text = 'UK'
	$radiobuttonUK.UseVisualStyleBackColor = $True
	#
	# notifyicon1
	#
	$notifyicon1.Text = 'notifyicon1'
	$notifyicon1.Visible = $True
	#
	# chart1
	#
	$System_Windows_Forms_DataVisualization_Charting_ChartArea_1 = New-Object 'System.Windows.Forms.DataVisualization.Charting.ChartArea'
	$System_Windows_Forms_DataVisualization_Charting_ChartArea_1.Name = 'ChartArea1'
	[void]$chart1.ChartAreas.Add($System_Windows_Forms_DataVisualization_Charting_ChartArea_1)
	$System_Windows_Forms_DataVisualization_Charting_Legend_2 = New-Object 'System.Windows.Forms.DataVisualization.Charting.Legend'
	$System_Windows_Forms_DataVisualization_Charting_Legend_2.Name = 'Legend1'
	[void]$chart1.Legends.Add($System_Windows_Forms_DataVisualization_Charting_Legend_2)
	$chart1.Location = '0, 0'
	$chart1.Margin = '4, 4, 4, 4'
	$chart1.Name = 'chart1'
	$System_Windows_Forms_DataVisualization_Charting_Series_3 = New-Object 'System.Windows.Forms.DataVisualization.Charting.Series'
	$System_Windows_Forms_DataVisualization_Charting_Series_3.ChartArea = 'ChartArea1'
	$System_Windows_Forms_DataVisualization_Charting_Series_3.Legend = 'Legend1'
	$System_Windows_Forms_DataVisualization_Charting_Series_3.Name = 'Series1'
	[void]$chart1.Series.Add($System_Windows_Forms_DataVisualization_Charting_Series_3)
	$chart1.Size = '400, 392'
	$chart1.TabIndex = 0
	$chart1.Text = 'chart1'
	$chart1.EndInit()
	$panel2.ResumeLayout()
	$panel1.ResumeLayout()
	$AgentTab.ResumeLayout()
	$EmployeeTab.ResumeLayout()
	$tabcontrol.ResumeLayout()
	$panel3.ResumeLayout()
	$formOpenHRADMembershipTo.ResumeLayout()
	#endregion Generated Form Code

	#----------------------------------------------

	#Save the initial state of the form
	$InitialFormWindowState = $formOpenHRADMembershipTo.WindowState
	#Init the OnLoad event to correct the initial state of the form
	$formOpenHRADMembershipTo.add_Load($Form_StateCorrection_Load)
	#Clean up the control events
	$formOpenHRADMembershipTo.add_FormClosed($Form_Cleanup_FormClosed)
	#Show the Form
	return $formOpenHRADMembershipTo.ShowDialog()

} #End Function

#Call the form
Call-new_user_psf | Out-Null
